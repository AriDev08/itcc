export declare const getDirectChildren: (parent: Element, sel?: string) => Element[];
