export declare const isPlainObject: (obj: any) => boolean;
