export declare const merge: <T extends Record<string, any>>(target: T, ...sources: T[]) => T;
