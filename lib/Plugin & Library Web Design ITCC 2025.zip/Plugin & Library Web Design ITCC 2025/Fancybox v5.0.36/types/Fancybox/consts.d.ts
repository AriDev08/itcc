export declare enum States {
    Init = 0,
    Ready = 1,
    Closing = 2,
    CustomClosing = 3,
    Destroy = 4
}
export declare enum SlideStates {
    Loading = 0,
    Opening = 1,
    Ready = 2,
    Closing = 3
}
