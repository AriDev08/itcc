import { PluginsType } from "../types";
export type * from "./Hash/Hash";
export type * from "./Images/Images";
export type * from "./Html/Html";
export type * from "./Slideshow/Slideshow";
export type * from "./Thumbs/Thumbs";
export type * from "./Toolbar/Toolbar";
export declare const FancyboxPlugins: PluginsType;
