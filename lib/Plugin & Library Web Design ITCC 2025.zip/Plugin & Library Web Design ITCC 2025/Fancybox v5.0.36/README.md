# Fancyapps UI

Collection of task-oriented components that will make you more productive. 
Packed full of features that you and your clients will love.

Full docs with examples: https://fancyapps.com/

## License

This is commercial software. See [LICENSE.md](LICENSE.md) for more info.